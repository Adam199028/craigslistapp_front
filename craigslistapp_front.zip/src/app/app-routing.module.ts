import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AutoLoginGuard } from './guards/auto-login.guard';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule),
    
  },
  {
    path: 'portfolio',
    loadChildren: () => import('./portfolio/portfolio.module').then( m => m.PortfolioPageModule),
    canLoad: [AuthGuard]
  },
  {
    path: 'phone-numbers',
    loadChildren: () => import('./phone-numbers/phone-numbers.module').then( m => m.PhoneNumbersPageModule)
  },
  {
    path: 'login-and-register',
    loadChildren: () => import('./login-and-register/login-and-register.module').then( m => m.LoginAndRegisterPageModule),
    canLoad: [AutoLoginGuard]
  },
  {
    path: 'find-work',
    loadChildren: () => import('./find-work/find-work.module').then( m => m.FindWorkPageModule)
  },
  {
    path: 'give-work',
    loadChildren: () => import('./give-work/give-work.module').then( m => m.GiveWorkPageModule)
  },
  {
    path: 'help',
    loadChildren: () => import('./help/help.module').then( m => m.HelpPageModule)
  },
  {
    path: 'notification',
    loadChildren: () => import('./notification/notification.module').then( m => m.NotificationPageModule)
  },
  {
    path: 'marketplace',
    loadChildren: () => import('./marketplace/marketplace.module').then( m => m.MarketplacePageModule)
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
