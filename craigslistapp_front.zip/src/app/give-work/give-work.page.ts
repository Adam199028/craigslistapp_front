import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Plugins, NetworkStatus, PluginListenerHandle } from '@capacitor/core';
const { Network } = Plugins;
import { JargonValidator } from './../validators/jargon';
import { PhoneValidator } from '../validators/phone';
import { ApiService } from '../services/api.service';
import { Router } from '@angular/router';
import { AlertController, LoadingController } from '@ionic/angular';

declare var window
@Component({
  selector: 'app-give-work',
  templateUrl: './give-work.page.html',
  styleUrls: ['./give-work.page.scss'],
})
export class GiveWorkPage implements OnInit, OnDestroy {

  constructor(
    private _translate: TranslateService,
    private cd: ChangeDetectorRef,
    private apiService: ApiService,
    private router: Router,
    private loadingController: LoadingController,
    private alertController: AlertController
  ) {
    window.givework = this
   }

  REGIONS = ['Toshkent shahri', 'Toshkent viloyati', "Farg'ona viloyati", 'Andijon viloyati', 
  'Namangan viloyati', "Jizzax viloyati", 'Sirdaryo viloyati', 'Qashqadaryo viloyati', 
  "Surxondaryo viloyati", 'Samarqand viloyati', 'Buxoro viloyati', 'Navoiy viloyati', 
  'Xorazm viloyati', "Qoraqalpog'iston Respublikasi"]
  
  DISTRICTS = [
    // Toshkent shahar
    [" Bektemir tumani", "Chilonzor tumani", "Hamza tumani",
    "Mirobod tumani", "Mirzo Ulug'bek tumani", 
    "Sergeli tumani", "Shayxontohur tumani", "Olmazor tumani", 
    "Uchtepa", "Yakkasaroy tumani", "Yunusobod tumani"],
    // Toshkent viloyati
    ["Bekobod tumani", "Bo'stonliq tumani", "Bo'ka tumani",
    "Chinoz tumani", "Qibray tumani",
    "Ohangaron tumani", "Oqqo'rg'on tumani", "Parkent tumani", 
    "Piskent tumani", "Quyi chirchiq tumani", "O'rta Chirchiq tumani",
    "Yangiyo'l tumani", "Yuqori Chirchiq tumani", "Zangiota tumani"],
    // Farg'ona
    ["Oltiariq tumani", "Bag'dod tumani", "Beshariq tumani",
    "Buvayda tumani", "Dang'ara tumani", "Farg'ona tumani",
    "Furqat tumani", "Qo'shtepa tumani","Quva tumani",
    "Rishton tumani", "So'x tumani", "Toshloq tumani",
    "Uchko'prik tumani", "O'zbekiston tumani", "Yozyovon tumani"],
    // Andijon
    ["Andijon tumani", "Asaka tumani", "Baliqchi tumani",
    "Bo'z tumani", "Buloqboshi tumani", "Izboskan tumani",
    "Jalaquduq tumani", "Xo'jaobod tumani", "Qo'rg'ontepa tumani",
    "Marhamat tumani", "Oltinko'l tumani", "Paxtaobod tumani",
    "Shahrixon tumani", "Ulug'nor tumani"],
    // Namangan
    ["Chortoq tumani",
    "Chust tumani",
    "Kosonsoy tumani",
    "Mingbuloq tumani",
    "Namangan tumani",
    "Norin tumani",
    "Pop tumani",
    "To'raqo'rg'on tumani",
    "Uchqo'rg'on tumani",
    "Uychi tumani",
    "Yangiqo'rg'on tumani"],
    // Jizzax 
    ["Arnasoy tumani",
    "Baxmal tumani",
    "Do'stlik tumani",
    "Forish tumani",
    "G'allaorol tumani",
    "Sharof Rashidov tumani",
    "Mirzacho'l tumani",
    "Paxtakor tumani",
    "Yangiobod tumani",
    "Zomin tumani",
    "Zafarobod tumani",
    "Zarbdor tumani"],
    // Sirdaryo
    ["Oqoltin tumani",
    "Boyovut tumani",
    "Guliston tumani",
    "Xovos tumani",
    "Mirzaobod tumani",
    "Sayxunobod tumani",
    "Sardoba tumani",
    "Sirdaryo tumani"],
    // Qashqadaryo
    ["Chiroqchi tumani",
    "Dehqonobod tumani",
    "G'uzor tumani",
    "Qamashi tumani",
    "Qarshi tumani",
    "Koson tumani",
    "Kasbi tumani",
    "Kitob tumani",
    "Mirishkor tumani",
    "Muborak tumani",
    "Nishon tumani",
    "Shahrisabz tumani",
    "Yakkabog' tumani"],
    // Surxondaryo
    ["Angor tumani",
    "Boysun tumani",
    "Denov tumani",
    "Jarqo'rg'on tumani",
    "Qiziriq tumani",
    "Qumqo'rg'on tumani",
    "Muzrabot tumani",
    "Oltinsoy tumani",
    "Sariosiyo tumani",
    "Sherobod tumani",
    "Sho'rchi tumani",
    "Termiz tumani",
    "Uzun tumani"],
    // Samarqand
    ["Bulung'ur tumani",
    "Ishtixon tumani",
    "Jomboy tumani",
    "Kattaqo'rg'on tumani",
    "Qo'shrabot tumani",
    "Narpay tumani",
    "Nurobod tumani",
    "Oqdaryo tumani",
    "Paxtachi tumani",
    "Payariq tumani",
    "Pastdarg'om tumani",
    "Samarqand tumani",
    "Toyloq tumani",
    "Urgut tumani"],
    // Buxoro
    ["Olot tumani",
    "Buxoro tumani",
    "G'ijduvon tumani",
    "Jondor tumani",
    "Kogon tumani",
    "Qorako'l tumani",
    "Qorovulbozor tumani",
    "Peshku tumani",
    "Romitan tumani",
    "Shofirkon tumani",
    "Vobkent tumani"],
    // Navoiy
    ["Konimex tumani",
    "Karmana tumani",
    "Qiziltepa tumani",
    "Xatirchi tumani",
    "Navbahor tumani",
    "Nurota tumani",
    "Tomdi tumani",
    "Uchquduq tumani"],
    // Xorazm
    ["Bog'ot tumani",
    "Gurlan tumani",
    "Xonqa tumani",
    "Hazorasp tumani",
    "Xiva tumani",
    "Qo'shko'pir tumani",
    "Shovot tumani",
    "Urganch tumani",
    "Yangiariq tumani",
    "Yangibozor tumani",
    "Tuproqqal'a tumani"],
    // Qoraqalpog'iston 
    ["Amudaryo tumani",
    "Beruniy tumani",
    "Chimboy tumani",
    "Ellikqal'a tumani",
    "Kegeyli tumani",
    "Mo'ynoq tumani",
    "Nukus tumani",
    "Qanliko'l tumani",
    "Qo'ng'irot tumani",
    "Qorao'zak tumani",
    "Shumanay tumani",
    "Taxtako'pir tumani",
    "To'rtko'l tumani",
    "Xo'jayli tumani"]

  ]
  SelectDistrict = []

  need_workerForm = new FormGroup({
    org_name: new FormControl("", Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    work_category: new FormControl("", Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    region: new FormControl('', Validators.required),
    district: new FormControl('', Validators.required),
    phone_number: new FormControl("", Validators.compose([
      PhoneValidator.isValid,
      Validators.required
    ])),
    payload: new FormControl("", Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    requests: new FormControl("",Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    work_desc: new FormControl("",Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    connect_time: new FormControl("",Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
  });

  ask_workForm = new FormGroup({
    fullname: new FormControl('', Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    work_category: new FormControl('', Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    region: new FormControl('', Validators.required),
    district: new FormControl('', Validators.required),
    phone_number: new FormControl("", Validators.compose([
      PhoneValidator.isValid,
      Validators.required
    ])),
    payload: new FormControl("", Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    login_portfolio: new FormControl('',Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    intent: new FormControl('',Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    connect_time: new FormControl('',Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
  });

  support_workForm = new FormGroup({
    fullname: new FormControl('', Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    work_category: new FormControl('', Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    region: new FormControl('', Validators.required),
    district: new FormControl('', Validators.required),
    phone_number: new FormControl("", Validators.compose([
      PhoneValidator.isValid,
      Validators.required
    ])),
    login_portfolio: new FormControl('',Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    intent: new FormControl('',Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    work_desc: new FormControl("",Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    connect_time: new FormControl('',Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
  });


  buy_workForm = new FormGroup({
    fullname: new FormControl('', Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    product_category: new FormControl('', Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    region: new FormControl('', Validators.required),
    district: new FormControl('', Validators.required),
    phone_number: new FormControl("", Validators.compose([
      PhoneValidator.isValid,
      Validators.required
    ])),
    price: new FormControl('',Validators.compose([
      PhoneValidator.isValid,
      Validators.required
    ])),
    product_desc: new FormControl("",Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    connect_time: new FormControl('',Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
  });

  sell_workForm = new FormGroup({
    fullname: new FormControl('', Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    product_category: new FormControl('', Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    region: new FormControl('', Validators.required),
    district: new FormControl('', Validators.required),
    phone_number: new FormControl("", Validators.compose([
      PhoneValidator.isValid,
      Validators.required
    ])),
    price: new FormControl('',Validators.compose([
      PhoneValidator.isValid,
      Validators.required
    ])),
    product_desc: new FormControl("",Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    connect_time: new FormControl('',Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
  });

  networkStatus: NetworkStatus;
  networkListener: PluginListenerHandle;

  needWorkerHidden: boolean = false
  askWorkHidden: boolean = false
  supportHidden: boolean = false
  buyHidden: boolean = false
  sellHidden: boolean = false

  currency = "so\'m"

  async ngOnInit() {
    let lang = window.localStorage.getItem("LanguageInterface");
    if(lang == null){
      this.changeLanguage("uz")
    }
    else{
      this.changeLanguage(lang)
    }
    this.networkListener = Network.addListener('networkStatusChange', (status) => {
      console.log("Network status changed", status);
      this.networkStatus = status;
    });

    this.networkStatus = await Network.getStatus();

  }

  ngOnDestroy() {
    this.networkListener.remove();
  }

  public changeLanguage(language): void {
    this._translate.use(language);
  }

  async ask_workSave(form){
    if (this.networkStatus && this.networkStatus.connected) {
      const loading = await this.loadingController.create({
        spinner: "bubbles",
        message: "Ma'lumotlar yuborilmoqda ...",
        translucent: true
      });
      await loading.present();
      this.apiService.newItem(this.ask_workForm.value, "/add_ask_work").subscribe(async res =>{
        if(res["success"] == true){
          await loading.dismiss()
          this.askWorkFormReset()
          const alert = await this.alertController.create({
            header: "Ma'lumot saqlandi.",
            message: "",
            buttons: ['OK'],
          });
    
          await alert.present();
        }
        else{
          await loading.dismiss()
        }
      })
    }
    else {
      const alert = await this.alertController.create({
        header: "Internetga ulanmagansiz.",
        message: "",
        buttons: ['OK'],
      });

      await alert.present();
    }
  }

  askWorkFormReset(){
    this.ask_workForm = new FormGroup({
      fullname: new FormControl('', Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      work_category: new FormControl('', Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      region: new FormControl('', Validators.required),
      district: new FormControl('', Validators.required),
      phone_number: new FormControl("", Validators.compose([
        PhoneValidator.isValid,
        Validators.required
      ])),
      payload: new FormControl("", Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      login_portfolio: new FormControl('',Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      intent: new FormControl('',Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      connect_time: new FormControl('',Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
    });
  }

  async need_workerSave(form){
    if (this.networkStatus && this.networkStatus.connected) {
      const loading = await this.loadingController.create({
        spinner: "bubbles",
        message: "Ma'lumotlar yuborilmoqda ...",
        translucent: true
      });
      await loading.present();
      this.apiService.newItem(this.need_workerForm.value, "/add_need_worker").subscribe(async res =>{
        if(res["success"] == true){
          await loading.dismiss()
          this.needWorkFormReset()
          const alert = await this.alertController.create({
            header: "Ma'lumot saqlandi.",
            message: "",
            buttons: ['OK'],
          });
    
          await alert.present();
        }
        else{
          await loading.dismiss()
        }
      })
    }
    else {
      const alert = await this.alertController.create({
        header: "Internetga ulanmagansiz.",
        message: "",
        buttons: ['OK'],
      });

      await alert.present();
    }
  }

  needWorkFormReset(){
    this.need_workerForm = new FormGroup({
      org_name: new FormControl("", Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      work_category: new FormControl("", Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      region: new FormControl('', Validators.required),
      district: new FormControl('', Validators.required),
      phone_number: new FormControl("", Validators.compose([
        PhoneValidator.isValid,
        Validators.required
      ])),
      payload: new FormControl("", Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      requests: new FormControl("",Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      work_desc: new FormControl("",Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      connect_time: new FormControl("",Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
    });
  }

  async support_workSave(form){
    
    if (this.networkStatus && this.networkStatus.connected) {
      const loading = await this.loadingController.create({
        spinner: "bubbles",
        message: "Ma'lumotlar yuborilmoqda ...",
        translucent: true
      });
      await loading.present();
      this.apiService.newItem(this.support_workForm.value, "/add_support_work").subscribe(async res =>{
        if(res["success"] == true){
          await loading.dismiss()
          this.supportFormReset()
          const alert = await this.alertController.create({
            header: "Ma'lumot saqlandi.",
            message: "",
            buttons: ['OK'],
          });
    
          await alert.present();
        }
        else{
          await loading.dismiss()
        }
      })
    }
    else {
      const alert = await this.alertController.create({
        header: "Internetga ulanmagansiz.",
        message: "",
        buttons: ['OK'],
      });

      await alert.present();
    }
  }

  supportFormReset(){
    this.support_workForm = new FormGroup({
      fullname: new FormControl('', Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      work_category: new FormControl('', Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      region: new FormControl('', Validators.required),
      district: new FormControl('', Validators.required),
      phone_number: new FormControl("", Validators.compose([
        PhoneValidator.isValid,
        Validators.required
      ])),
      login_portfolio: new FormControl('',Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      intent: new FormControl('',Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      work_desc: new FormControl("",Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      connect_time: new FormControl('',Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
    });
  }

  async buy_workSave(form){
    
    if (this.networkStatus && this.networkStatus.connected) {
      const loading = await this.loadingController.create({
        spinner: "bubbles",
        message: "Ma'lumotlar yuborilmoqda ...",
        translucent: true
      });
      await loading.present();
      this.buy_workForm.value["price"] = this.buy_workForm.value["price"] + " " + this.currency
      console.log(this.buy_workForm.value)
      this.apiService.newItem(this.buy_workForm.value, "/add_buy_work").subscribe(async res =>{
        if(res["success"] == true){
          await loading.dismiss()
          this.buyFormReset()
          const alert = await this.alertController.create({
            header: "Ma'lumot saqlandi.",
            message: "",
            buttons: ['OK'],
          });
    
          await alert.present();
        }
        else{
          await loading.dismiss()
        }
      })
    }
    else {
      const alert = await this.alertController.create({
        header: "Internetga ulanmagansiz.",
        message: "",
        buttons: ['OK'],
      });

      await alert.present();
    }
  }

  buyFormReset(){
    this.buy_workForm = new FormGroup({
      fullname: new FormControl('', Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      product_category: new FormControl('', Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      region: new FormControl('', Validators.required),
      district: new FormControl('', Validators.required),
      phone_number: new FormControl("", Validators.compose([
        PhoneValidator.isValid,
        Validators.required
      ])),
      price: new FormControl('',Validators.compose([
        PhoneValidator.isValid,
        Validators.required
      ])),
      product_desc: new FormControl("",Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      connect_time: new FormControl('',Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
    });
  }

  async sell_workSave(form){
    
    if (this.networkStatus && this.networkStatus.connected) {
      const loading = await this.loadingController.create({
        spinner: "bubbles",
        message: "Ma'lumotlar yuborilmoqda ...",
        translucent: true
      });
      await loading.present();
      this.buy_workForm.value["price"] = this.buy_workForm.value["price"] + " " + this.currency
      this.apiService.newItem(this.sell_workForm.value, "/add_sell_work").subscribe(async res =>{
        if(res["success"] == true){
          await loading.dismiss()
          this.sellFormReset()
          const alert = await this.alertController.create({
            header: "Ma'lumot saqlandi.",
            message: "",
            buttons: ['OK'],
          });
    
          await alert.present();
        }
        else{
          await loading.dismiss()
        }
      })
    }
    else {
      const alert = await this.alertController.create({
        header: "Internetga ulanmagansiz.",
        message: "",
        buttons: ['OK'],
      });

      await alert.present();
    }
  }

  sellFormReset(){
    this.sell_workForm = new FormGroup({
      fullname: new FormControl('', Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      product_category: new FormControl('', Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      region: new FormControl('', Validators.required),
      district: new FormControl('', Validators.required),
      phone_number: new FormControl("", Validators.compose([
        PhoneValidator.isValid,
        Validators.required
      ])),
      price: new FormControl('',Validators.compose([
        PhoneValidator.isValid,
        Validators.required
      ])),
      product_desc: new FormControl("",Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
      connect_time: new FormControl('',Validators.compose([
        JargonValidator.isValid,
        Validators.required
      ])),
    });
  }

  changeForm(event){
    console.log(event.target.value)
    
    if(event.target.value == "Ishchi kerak"){
      this.needWorkerHidden = true;
      this.askWorkHidden = false
      this.supportHidden = false
      this.buyHidden = false
      this.sellHidden = false
      this.cd.detectChanges();
    }
    else if(event.target.value == "Ish kerak"){
      this.needWorkerHidden = false;
      this.askWorkHidden = true
      this.supportHidden = false
      this.buyHidden = false
      this.sellHidden = false
      this.cd.detectChanges();
    }
    else if(event.target.value == "Homiy kerak"){
      this.needWorkerHidden = false;
      this.askWorkHidden = false
      this.supportHidden = true
      this.buyHidden = false
      this.sellHidden = false
      this.cd.detectChanges();
    }
    else if(event.target.value == "Sotib olaman"){
      this.needWorkerHidden = false;
      this.askWorkHidden = false
      this.supportHidden = false
      this.buyHidden = true
      this.sellHidden = false
      this.cd.detectChanges();
    }
    else if(event.target.value == "Sotaman"){
      this.needWorkerHidden = false;
      this.askWorkHidden = false
      this.supportHidden = false
      this.buyHidden = false
      this.sellHidden = true
      this.cd.detectChanges();
    }
  }

  change(event){
    console.log(event.target.value)
    let i = this.REGIONS.findIndex(item => item == event.target.value)
    this.SelectDistrict = this.DISTRICTS[i];
  }

}
