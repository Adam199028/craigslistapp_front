import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GiveWorkPage } from './give-work.page';

const routes: Routes = [
  {
    path: '',
    component: GiveWorkPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GiveWorkPageRoutingModule {}
