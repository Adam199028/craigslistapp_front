import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { GiveWorkPage } from './give-work.page';

describe('GiveWorkPage', () => {
  let component: GiveWorkPage;
  let fixture: ComponentFixture<GiveWorkPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GiveWorkPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(GiveWorkPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
