import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../services/api.service';
import { AlertController, LoadingController } from '@ionic/angular';
import { AuthenticationService } from './../services/authentication.service';
import { Plugins, NetworkStatus, PluginListenerHandle } from '@capacitor/core';
import { JargonValidator } from './../validators/jargon';
import { TranslateService } from '@ngx-translate/core';
import { ErrorValueValidator } from '../validators/errorValue';
const { Network } = Plugins;
const { Storage } = Plugins

declare var window
const TOKEN_KEY = 'my-token';


@Component({
  selector: 'app-login-and-register',
  templateUrl: './login-and-register.page.html',
  styleUrls: ['./login-and-register.page.scss'],
})
export class LoginAndRegisterPage implements OnInit, OnDestroy {

  constructor(
    private _translate: TranslateService,
    private apiService: ApiService,
    private fb: FormBuilder,
    private authService: AuthenticationService,
    private alertController: AlertController,
    private router: Router,
    private loadingController: LoadingController,

  ) { 
    window.login = this
  }

  networkStatus: NetworkStatus;
  networkListener: PluginListenerHandle;

  
  showLogin: boolean = true;
  showReg: boolean = false;
  showRec: boolean = false;
  warning = "";

  loginForm = new FormGroup({
    login: new FormControl('', Validators.compose([
      ErrorValueValidator.isValid,
      Validators.required
    ])),
    password: new FormControl(''),
  });

  registerForm = new FormGroup({
    login: new FormControl('', Validators.compose([
      ErrorValueValidator.isValid,
      Validators.minLength(5),
      Validators.required
    ])),
    email: new FormControl('', Validators.compose([
      Validators.required,
      Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
    ])),
    password: new FormControl(''),
    stars: new FormControl('0'),
  });

  recoveryForm = new FormGroup({
    email: new FormControl('', Validators.compose([
      Validators.required,
      Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
    ]))
  });

  showPass: boolean = false;

  

  async ngOnInit() {
    let lang = window.localStorage.getItem("LanguageInterface");
    if(lang == null){
      this.changeLanguage("uz")
    }
    else{
      this.changeLanguage(lang)
    }
    this.networkListener = Network.addListener('networkStatusChange', (status) => {
      console.log("Network status changed", status);
      this.networkStatus = status;
    });

    this.networkStatus = await Network.getStatus();
  }

  ngOnDestroy() {
    this.networkListener.remove();
  }

  public changeLanguage(language): void {
    this._translate.use(language);
  }

  async login(form) {
    if (this.networkStatus && this.networkStatus.connected) {
      const loading = await this.loadingController.create();
      await loading.present();

      let query = "/search_users_username";
      let username = form.value.login

      

      this.authService.login(this.loginForm.value, query).subscribe(
        async (res) => {
          
          if (res["success"] == true) {
            Storage.set({ key: TOKEN_KEY, value: res["token"] })
            this.authService.isAuthenticated.next(true)
            await loading.dismiss();
            window.localStorage.setItem("UserID", res["id"])
            window.app.hide()
            this.router.navigateByUrl('/portfolio');
          }
          else {
            await loading.dismiss();
            if (username.indexOf("@") !== -1) {
              this.warning = "Pochta nomi yoki parol noto'g'ri kiritildi."
            }
            else {
              this.warning = "Login nomi yoki parol noto'g'ri kiritildi."
            }

          }
        },
        async (res) => {
          
          await loading.dismiss();
          const alert = await this.alertController.create({
            header: "Server bilan bog'lanish yo'q",
            message: "",
            buttons: ['OK'],
          });

          await alert.present();
        }
      );
    }
    else {
      const alert = await this.alertController.create({
        header: "Internetga ulanmagansiz.",
        message: "",
        buttons: ['OK'],
      });

      await alert.present();
    }

  }



  async register(form) {
    if (this.networkStatus && this.networkStatus.connected) {
      let username = form.value.login
      let email = form.value.email

      const loading = await this.loadingController.create();
      await loading.present();

      this.apiService.getSearchItem("/search_users_usernamefilter/" + username).subscribe(async res1 => {

        if (res1.length == 0) {
          this.warning = ""
          this.apiService.getSearchItem("/search_users_emailfilter/" + email).subscribe(async res2 => {

            if (res2.length == 0) {
              this.warning = ""
              this.apiService.newItem(form.value, "/newuser_account").subscribe(async result => {

                if (result["success"] == true) {
                  Storage.set({ key: TOKEN_KEY, value: result["token"] })
                  this.authService.isAuthenticated.next(true);
                  await loading.dismiss();
                  window.localStorage.setItem("UserID", result["id"])

                  window.app.hide()
                  this.router.navigateByUrl('/portfolio');

                }
              })
            }
            else {
              await loading.dismiss();
              this.warning = "Bunday pochta nomi avval ro'yxatdan o'tgan."
            }

          })
        }
        else {
          await loading.dismiss();
          this.warning = "Bunday login nomi avval ro'yxatdan o'tgan."
        }
      })
    }
    else {
      const alert = await this.alertController.create({
        header: "Internetga ulanmagansiz.",
        message: "",
        buttons: ['OK'],
      });

      await alert.present();
    }

  }

  recovery(form) { }

}
