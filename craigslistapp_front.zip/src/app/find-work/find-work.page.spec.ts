import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { FindWorkPage } from './find-work.page';

describe('FindWorkPage', () => {
  let component: FindWorkPage;
  let fixture: ComponentFixture<FindWorkPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FindWorkPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(FindWorkPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
