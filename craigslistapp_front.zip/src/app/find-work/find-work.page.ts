import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { Plugins, NetworkStatus, PluginListenerHandle } from '@capacitor/core';
import { TranslateService } from '@ngx-translate/core';
const { Network } = Plugins;
import { JargonValidator } from './../validators/jargon';
import { ApiService } from '../services/api.service';
import { Router } from '@angular/router';
import { AlertController, LoadingController } from '@ionic/angular';
const { Storage } = Plugins
import { Chart } from 'chart.js';
import { PhoneValidator } from '../validators/phone';

declare var window
@Component({
  selector: 'app-find-work',
  templateUrl: './find-work.page.html',
  styleUrls: ['./find-work.page.scss'],
})
export class FindWorkPage implements OnInit, OnDestroy {

  constructor(
    private _translate: TranslateService,
    private apiService: ApiService,
    private router: Router,
    private loadingController: LoadingController,
    private alertController: AlertController
  ) {
    
    window.findwork = this
  }

  
  
  workForm = new FormGroup({
    selectCategory: new FormControl('Ishchi kerak', Validators.required),
    region: new FormControl("", Validators.required),
    district: new FormControl("", Validators.required)    
  });

  @ViewChild('lineCanvas', { static: false }) lineCanvas: any;
  lineChart: any;

  searchWork = "Qidiruv"

  REGIONS = ['Toshkent shahri', 'Toshkent viloyati', "Farg'ona viloyati", 'Andijon viloyati', 
  'Namangan viloyati', "Jizzax viloyati", 'Sirdaryo viloyati', 'Qashqadaryo viloyati', 
  "Surxondaryo viloyati", 'Samarqand viloyati', 'Buxoro viloyati', 'Navoiy viloyati', 
  'Xorazm viloyati', "Qoraqalpog'iston Respublikasi"]
  
  DISTRICTS = [
    // Toshkent shahar
    [" Bektemir tumani", "Chilonzor tumani", "Hamza tumani",
    "Mirobod tumani", "Mirzo Ulug'bek tumani", 
    "Sergeli tumani", "Shayxontohur tumani", "Olmazor tumani", 
    "Uchtepa", "Yakkasaroy tumani", "Yunusobod tumani"],
    // Toshkent viloyati
    ["Bekobod tumani", "Bo'stonliq tumani", "Bo'ka tumani",
    "Chinoz tumani", "Qibray tumani",
    "Ohangaron tumani", "Oqqo'rg'on tumani", "Parkent tumani", 
    "Piskent tumani", "Quyi chirchiq tumani", "O'rta Chirchiq tumani",
    "Yangiyo'l tumani", "Yuqori Chirchiq tumani", "Zangiota tumani"],
    // Farg'ona
    ["Oltiariq tumani", "Bag'dod tumani", "Beshariq tumani",
    "Buvayda tumani", "Dang'ara tumani", "Farg'ona tumani",
    "Furqat tumani", "Qo'shtepa tumani","Quva tumani",
    "Rishton tumani", "So'x tumani", "Toshloq tumani",
    "Uchko'prik tumani", "O'zbekiston tumani", "Yozyovon tumani"],
    // Andijon
    ["Andijon tumani", "Asaka tumani", "Baliqchi tumani",
    "Bo'z tumani", "Buloqboshi tumani", "Izboskan tumani",
    "Jalaquduq tumani", "Xo'jaobod tumani", "Qo'rg'ontepa tumani",
    "Marhamat tumani", "Oltinko'l tumani", "Paxtaobod tumani",
    "Shahrixon tumani", "Ulug'nor tumani"],
    // Namangan
    ["Chortoq tumani",
    "Chust tumani",
    "Kosonsoy tumani",
    "Mingbuloq tumani",
    "Namangan tumani",
    "Norin tumani",
    "Pop tumani",
    "To'raqo'rg'on tumani",
    "Uchqo'rg'on tumani",
    "Uychi tumani",
    "Yangiqo'rg'on tumani"],
    // Jizzax 
    ["Arnasoy tumani",
    "Baxmal tumani",
    "Do'stlik tumani",
    "Forish tumani",
    "G'allaorol tumani",
    "Sharof Rashidov tumani",
    "Mirzacho'l tumani",
    "Paxtakor tumani",
    "Yangiobod tumani",
    "Zomin tumani",
    "Zafarobod tumani",
    "Zarbdor tumani"],
    // Sirdaryo
    ["Oqoltin tumani",
    "Boyovut tumani",
    "Guliston tumani",
    "Xovos tumani",
    "Mirzaobod tumani",
    "Sayxunobod tumani",
    "Sardoba tumani",
    "Sirdaryo tumani"],
    // Qashqadaryo
    ["Chiroqchi tumani",
    "Dehqonobod tumani",
    "G'uzor tumani",
    "Qamashi tumani",
    "Qarshi tumani",
    "Koson tumani",
    "Kasbi tumani",
    "Kitob tumani",
    "Mirishkor tumani",
    "Muborak tumani",
    "Nishon tumani",
    "Shahrisabz tumani",
    "Yakkabog' tumani"],
    // Surxondaryo
    ["Angor tumani",
    "Boysun tumani",
    "Denov tumani",
    "Jarqo'rg'on tumani",
    "Qiziriq tumani",
    "Qumqo'rg'on tumani",
    "Muzrabot tumani",
    "Oltinsoy tumani",
    "Sariosiyo tumani",
    "Sherobod tumani",
    "Sho'rchi tumani",
    "Termiz tumani",
    "Uzun tumani"],
    // Samarqand
    ["Bulung'ur tumani",
    "Ishtixon tumani",
    "Jomboy tumani",
    "Kattaqo'rg'on tumani",
    "Qo'shrabot tumani",
    "Narpay tumani",
    "Nurobod tumani",
    "Oqdaryo tumani",
    "Paxtachi tumani",
    "Payariq tumani",
    "Pastdarg'om tumani",
    "Samarqand tumani",
    "Toyloq tumani",
    "Urgut tumani"],
    // Buxoro
    ["Olot tumani",
    "Buxoro tumani",
    "G'ijduvon tumani",
    "Jondor tumani",
    "Kogon tumani",
    "Qorako'l tumani",
    "Qorovulbozor tumani",
    "Peshku tumani",
    "Romitan tumani",
    "Shofirkon tumani",
    "Vobkent tumani"],
    // Navoiy
    ["Konimex tumani",
    "Karmana tumani",
    "Qiziltepa tumani",
    "Xatirchi tumani",
    "Navbahor tumani",
    "Nurota tumani",
    "Tomdi tumani",
    "Uchquduq tumani"],
    // Xorazm
    ["Bog'ot tumani",
    "Gurlan tumani",
    "Xonqa tumani",
    "Hazorasp tumani",
    "Xiva tumani",
    "Qo'shko'pir tumani",
    "Shovot tumani",
    "Urganch tumani",
    "Yangiariq tumani",
    "Yangibozor tumani",
    "Tuproqqal'a tumani"],
    // Qoraqalpog'iston 
    ["Amudaryo tumani",
    "Beruniy tumani",
    "Chimboy tumani",
    "Ellikqal'a tumani",
    "Kegeyli tumani",
    "Mo'ynoq tumani",
    "Nukus tumani",
    "Qanliko'l tumani",
    "Qo'ng'irot tumani",
    "Qorao'zak tumani",
    "Shumanay tumani",
    "Taxtako'pir tumani",
    "To'rtko'l tumani",
    "Xo'jayli tumani"]

  ]

  SelectDistrict = []
  
  WORK_CATEGORIES = ["Dasturchi", "O'qituvchi"]

  

  searchControl = new FormControl();
  rows: Observable<any[]>;

  needWorkerHidden: boolean = false
  askWorkHidden: boolean = false
  supportHidden: boolean = false

  buy_sellHidden: boolean = false


  @ViewChild('myTable', { static: false }) table: any;

  temp = [];
  go;

  check: boolean = false

  monthNames = ['yanvar', 'fevral', 'mart', 'aprel', 'may', 'iyun', 'iyul', 'avgust', 'sentabr', 'oktabr', 'noyabr', 'dekabr'];

  networkStatus: NetworkStatus;
  networkListener: PluginListenerHandle;

  showNeedWorkerInfoHidden: boolean = false
  showbuy_selWorkInfoHidden: boolean = false


  show_fullname = ""
  show_org_name = ""
  show_address = ""
  show_phone_number = ""
  show_activity = ""
  show_time = ""
  show_work_category = ""
  show_work_desc = ""
  show_payload = ""
  show_connect_time = ""
  show_requests = ""
  show_product_category = ""
  show_product_desc = ""
  show_price = ""


  searchHidden = true

  newPriceForm = new FormGroup({
    buy_sell_id: new FormControl(""),
    user_login: new FormControl(""),
    price: new FormControl("", Validators.compose([
      Validators.required,
      PhoneValidator.isValid
    ]))
  })


  async ngOnInit() {
    let lang = window.localStorage.getItem("LanguageInterface");
    if(lang == null){
      this.changeLanguage("uz")
      this.searchWork = "Qidiruv"
    }
    else{
      lang == "ru" ? this.searchWork = "Қидирув" : this.searchWork = "Qidiruv"
      this.changeLanguage(lang)
    }
    this.networkListener = Network.addListener('networkStatusChange', (status) => {
      console.log("Network status changed", status);
      this.networkStatus = status;
    });

    this.networkStatus = await Network.getStatus();

    const selectCategory = await Storage.get({ key: "selectCategory" });
    const region = await Storage.get({ key: "region" });
    const district = await Storage.get({ key: "district" });

    let i = this.REGIONS.findIndex(item => item == region.value)
    this.SelectDistrict = this.DISTRICTS[i];
  
    this.workForm = new FormGroup({
      selectCategory: new FormControl(selectCategory.value != null ? selectCategory.value : 'Ishchi kerak', Validators.required),
      region: new FormControl(region.value != null ? region.value : "", Validators.required),
      district: new FormControl(district.value != null ? district.value : "", Validators.required)
    });

    
    
  }

  ngOnDestroy() {
    this.networkListener.remove();
  }

  public changeLanguage(language): void {
    this._translate.use(language);
    language == "ru" ? this.searchWork = "Қидирув" : this.searchWork = "Qidiruv"
  }


  search(event){
    const val = event.target.value.toLowerCase();

    
    this.go = this.temp[0];
    const temper = this.go.filter(function(d) {
      return (d.name.toLowerCase().indexOf(val) !== -1 || !val);
            
    });
    this.rows = Observable.create(subscriber => {
      subscriber.next(temper);
  
    });
  
    this.table.offset = 0;
  }


  

  change(event){
    console.log(event.target.value)
    let i = this.REGIONS.findIndex(item => item == event.target.value)
    this.SelectDistrict = this.DISTRICTS[i];
  }

  async workSearch(form){
    Storage.set({ key: "selectCategory", value: form.value["selectCategory"]});
    Storage.set({ key: "district", value: form.value["district"]});
    Storage.set({ key: "region", value: form.value["region"]});
    
    if(form.value["selectCategory"] == "Ishchi kerak"){
      this.getInfo("/all_need_worker")
      this.needWorkerHidden = true;
      this.askWorkHidden = false
      this.supportHidden = false
      this.buy_sellHidden = false
    }
    else if(form.value["selectCategory"] == "Ish kerak"){
      this.getInfo("/all_ask_work")
      this.needWorkerHidden = false;
      this.askWorkHidden = true
      this.supportHidden = false
      this.buy_sellHidden = false
    }
    else if(form.value["selectCategory"] == "Homiy kerak"){
      this.getInfo("/all_support_work")
      this.needWorkerHidden = false;
      this.askWorkHidden = false
      this.supportHidden = true
      this.buy_sellHidden = false
    }
    else if(form.value["selectCategory"] == "Sotib olaman"){
      this.getInfo("/all_buy_work")
      this.needWorkerHidden = false;
      this.askWorkHidden = false
      this.supportHidden = false
      this.buy_sellHidden = true
    }
    else if(form.value["selectCategory"] == "Sotaman"){
      this.getInfo("/all_sell_work")
      this.needWorkerHidden = false;
      this.askWorkHidden = false
      this.supportHidden = false
      this.buy_sellHidden = true
    }
    
  }


  async getInfo(url){
    if (this.networkStatus && this.networkStatus.connected) {
      const loading = await this.loadingController.create({
        spinner: "bubbles",
        message: "Ma'lumotlar yuklanmoqda ...",
        translucent: true
      });
      await loading.present();
      this.apiService.getAllItem(url).subscribe(async data =>{
        
        for (let i = 0; i < data.length; i++) {
          data[i]['time'] = new Date(data[i]['time']).getDate() + "-" + this.monthNames[new Date(data[i]['time']).getMonth()] + "." + new Date(data[i]['time']).getFullYear()
          data[i]['region'] = data[i]['region'] + ", " + data[i]['district']
        }
        this.rows = Observable.create(subscriber => {
          subscriber.next(data);
          this.temp = [];
          this.temp.push(data);

        });
        await loading.dismiss()
      })
    }
    else {
      const alert = await this.alertController.create({
        header: "Internetga ulanmagansiz.",
        message: "",
        buttons: ['OK'],
      });

      await alert.present();
    }
  }

  showNeedWorkerInfo(index){
    this.show_time = this.temp[0][index]["time"]
    this.show_work_category = this.temp[0][index]["work_category"]
    this.show_work_desc = this.temp[0][index]["work_desc"]
    this.show_requests = this.temp[0][index]["requests"]
    this.show_payload = this.temp[0][index]["payload"]
    this.show_org_name = this.temp[0][index]["org_name"]
    this.show_phone_number = this.temp[0][index]["phone_number"]
    this.show_address = this.temp[0][index]["region"]
    this.show_connect_time = this.temp[0][index]["connect_time"]

    this.showNeedWorkerInfoHidden = true
    this.searchHidden = false
  }

  buySellId = 0;
  showbuy_selWorkInfo(index){
    this.showbuy_selWorkInfoHidden = true

    this.buySellId = this.temp[0][index]["id"]
    this.show_time = this.temp[0][index]["time"]
    this.show_fullname = this.temp[0][index]["fullname"]
    this.show_product_category = this.temp[0][index]["product_category"]
    this.show_product_desc = this.temp[0][index]["product_desc"]
    this.show_price = this.temp[0][index]["price"]
    this.show_phone_number = this.temp[0][index]["phone_number"]
    this.show_address = this.temp[0][index]["region"]
    this.show_connect_time = this.temp[0][index]["connect_time"]

    
    console.log()
    if(this.temp[0][index]["input_prices"] != ""){

      // try {
      //   this.lineChartMethod()
      // } catch (error) {
      //   this.lineChartMethod()
      // }
    }
    else if(this.temp[0][index]["input_prices"] == ""){
      try {
        this.lineChartMethod([])
      } catch (error) {
        this.lineChartMethod([])
      }
    }
    
    this.buy_sellHidden = false
    this.searchHidden = false
    
  }

  lineChartMethod(data) {
    
    this.lineChart = new Chart(this.lineCanvas.nativeElement, {
      type: 'line',
      data: {
        labels: data,
        datasets: [
          {
            label: 'Sell per week',
            fill: false,
            lineTension: 0.1,
            backgroundColor: 'rgba(75,192,192,0.4)',
            borderColor: 'rgba(75,192,192,1)',
            borderCapStyle: 'butt',
            borderDash: [],
            borderDashOffset: 0.0,
            borderJoinStyle: 'miter',
            pointBorderColor: 'rgba(75,192,192,1)',
            pointBackgroundColor: '#fff',
            pointBorderWidth: 1,
            pointHoverRadius: 5,
            pointHoverBackgroundColor: 'rgba(75,192,192,1)',
            pointHoverBorderColor: 'rgba(220,220,220,1)',
            pointHoverBorderWidth: 2,
            pointRadius: 1,
            pointHitRadius: 10,
            data: data,
            spanGaps: true,
          }
        ]
      }
    });
  }

  sendNewPrice(form){
    form.value["buy_sell_id"] = this.buySellId;
    form.value["user_login"] = "action";

    this.apiService.newItem(form.value, "/add_buy_new_price").subscribe(res =>{
      console.log(res)
    })
  }

}
