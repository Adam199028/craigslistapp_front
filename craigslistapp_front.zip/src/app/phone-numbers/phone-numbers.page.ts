import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertController, LoadingController } from '@ionic/angular';
import { Observable } from 'rxjs';
import { ApiService } from '../services/api.service';
import { Plugins, NetworkStatus, PluginListenerHandle } from '@capacitor/core';
import { TranslateService } from '@ngx-translate/core';
const { Network } = Plugins;

declare var window
@Component({
  selector: 'app-phone-numbers',
  templateUrl: './phone-numbers.page.html',
  styleUrls: ['./phone-numbers.page.scss'],
})
export class PhoneNumbersPage implements OnInit, OnDestroy {



  constructor(
    private _translate: TranslateService,
    private apiService: ApiService,
    private router: Router,
    private loadingController: LoadingController,
    private alertController: AlertController
  ) { 
    window.phone = this
  }

  networkStatus: NetworkStatus;
  networkListener: PluginListenerHandle;

  searchControl = new FormControl();
  rows: Observable<any[]>;

  @ViewChild('myTable', { static: false }) table: any;

  temp = [];
  go;

  leftHidden: boolean = false
  rightHidden: boolean = false

  

  monthNames = ['yanvar', 'fevral', 'mart', 'aprel', 'may', 'iyun', 'iyul', 'avgust', 'sentabr', 'oktabr', 'noyabr', 'dekabr'];

  phoneForm = new FormGroup({
    user_id: new FormControl(""),
    phone_number: new FormControl("", Validators.required),
    address: new FormControl("", Validators.required),
    org_name: new FormControl("", Validators.required),
    activity: new FormControl("", Validators.required)
  });


  show_org_name = ""
  show_address = ""
  show_phone_number = ""
  show_activity = ""
  show_time = ""

  showInfoHidden: boolean = false
  adminActive: boolean = false;
  showAddPhone: boolean = false;
  showListPhone: boolean = true;

  infoSum = 0;

  async ngOnInit() {
    let lang = window.localStorage.getItem("LanguageInterface");
    if(lang == null){
      this.changeLanguage("uz")
    }
    else{
      this.changeLanguage(lang)
    }

    this.networkListener = Network.addListener('networkStatusChange', (status) => {
      console.log("Network status changed", status);
      this.networkStatus = status;
    });

    this.networkStatus = await Network.getStatus();

    if (this.networkStatus && this.networkStatus.connected) {
      let id = 5;
      const loading = await this.loadingController.create({
        spinner: "bubbles",
        message: "Ma'lumotlar yuklanmoqda ...",
        translucent: true
      });
      await loading.present();
      this.apiService.newItem({from: (id-4), to: id}, "/phone_numbers").subscribe(async datas => {
        let data = datas["data"]
        console.log(datas["sum"])
        this.infoSum = datas["sum"]
        if(datas["sum"] > 5){
          this.rightHidden = true
        }
        for (let i = 0; i < data.length; i++) {
          data[i]['time'] = new Date(data[i]['time']).getDate() + "-" + this.monthNames[new Date(data[i]['time']).getMonth()] + "." + new Date(data[i]['time']).getFullYear()
        }
        this.rows = Observable.create(subscriber => {
          subscriber.next(data);
          this.temp = [];
          this.temp.push(data);

        });
        await loading.dismiss()
      })

      let info = window.localStorage.getItem("UserInfo")
      if (info == null) {
        this.adminActive = false;
      }
      else {
        let data = JSON.parse(info)
        if (data[0]["username"] == "action2133" || data[0]["username"] == "sanjar2003") {
          this.adminActive = true;
          this.phoneForm = new FormGroup({
            user_id: new FormControl(""),
            phone_number: new FormControl("", Validators.required),
            address: new FormControl("", Validators.required),
            org_name: new FormControl("", Validators.required),
            activity: new FormControl("", Validators.required)
          });
        }
        else {
          this.adminActive = false;
        }
      }
    }
    else {
      const alert = await this.alertController.create({
        header: "Internetga ulanmagansiz.",
        message: "",
        buttons: ['OK'],
      });

      await alert.present();
    }

  }

  ngOnDestroy() {
    this.networkListener.remove();
  }

  async rightLoadInfo(){
    if (this.networkStatus && this.networkStatus.connected) {
      let id = this.infoSum + 4;
      const loading = await this.loadingController.create({
        spinner: "bubbles",
        message: "Ma'lumotlar yuklanmoqda ...",
        translucent: true
      });
      await loading.present();
      this.apiService.newItem({from: (id-4), to: id}, "/phone_numbers").subscribe(async datas => {
        let data = datas["data"]
        console.log(datas["sum"])
        
        if(this.infoSum > id){
          this.rightHidden = true
        }
        else{
          this.leftHidden = true
          this.rightHidden = false
        }
        this.infoSum = datas["sum"]
        for (let i = 0; i < data.length; i++) {
          data[i]['time'] = new Date(data[i]['time']).getDate() + "-" + this.monthNames[new Date(data[i]['time']).getMonth()] + "." + new Date(data[i]['time']).getFullYear()
        }
        this.rows = Observable.create(subscriber => {
          subscriber.next(data);
          this.temp.push(data);

        });
        await loading.dismiss()
      })
    }
  }

  leftLoadInfo(){
    
  }

  public changeLanguage(language): void {
    this._translate.use(language);
  }

  async addPhone() {
    if (this.networkStatus && this.networkStatus.connected) {
      const loading = await this.loadingController.create();
      await loading.present();

      this.apiService.newItem(this.phoneForm.value, "/newphone_numbers").subscribe(async result => {
        console.log(result)
        let title = "";
        await loading.dismiss();
        if (result["success"] == true) {
          title = "Ma'lumotlar kiritildi."

        } else {
          if (result["status"] == "busy") {
            title = "Kechirasiz, bu telefon raqamni boshqa foydalanuvchi kiritgan. Admin: +998 90 309 39 78"
          }
          else {
            title = "Ma'lumotlar kiritishda xatolik yuzaga keldi."
          }

        }

        const alert = await this.alertController.create({
          header: title,
          message: "",
          buttons: ['OK'],
        });

        await alert.present();
      })
    }
    else {
      const alert = await this.alertController.create({
        header: "Internetga ulanmagansiz.",
        message: "",
        buttons: ['OK'],
      });

      await alert.present();
    }

  }

  showInfo(index){
    this.show_time = this.temp[0][index]["time"]
    this.show_activity = this.temp[0][index]["activity"]
    this.show_org_name = this.temp[0][index]["org_name"]
    this.show_phone_number = this.temp[0][index]["phone_number"]
    this.show_address = this.temp[0][index]["address"]
    
    this.showListPhone = false
    this.showAddPhone = false
    this.showInfoHidden = true
  }

  search(event) {
    const val = event.target.value.toLowerCase();
    this.go = this.temp[0];
    const temper = this.go.filter(function (d) {
      return (d.org_name.toLowerCase().indexOf(val) !== -1 || d.address.toLowerCase().indexOf(val) !== -1 || d.activity.toLowerCase().indexOf(val) !== -1 || !val);

    });
    this.rows = Observable.create(subscriber => {
      subscriber.next(temper);

    });

    this.table.offset = 0;
  }

}
