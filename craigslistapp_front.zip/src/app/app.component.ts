import { Component, OnInit } from '@angular/core';
import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { TranslateService } from '@ngx-translate/core';
import { filter, map, take } from 'rxjs/operators';
import { AuthenticationService } from './services/authentication.service';
import { Router } from '@angular/router';
import { Plugins, NetworkStatus, PluginListenerHandle } from '@capacitor/core';

const { Network } = Plugins;
import { BehaviorSubject } from 'rxjs';
import { ApiService } from './services/api.service';
const { Storage } = Plugins

export const INTRO_KEY = 'intro-seen';



declare var window
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent implements OnInit {
  public selectedIndex = 0;
  
  networkStatus: NetworkStatus;
  networkListener: PluginListenerHandle;

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private _translate: TranslateService,
    private authService: AuthenticationService,
    private router: Router,
    private apiService: ApiService
  ) {
    window.app = this;
    this.initializeApp();
    window.oncontextmenu = (e) => {
      e.preventDefault();
    }

    
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }

  endSide: boolean = true;
  language: string;
  showUzLanguageButton: boolean = false;
  showLoginButton: boolean = true;
  isAuthenticated: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(null);
  using_count = ""
  messages = "3"
  
  async ngOnInit() {
    
    let lang = window.localStorage.getItem("LanguageInterface");
    if(lang == null){
      this.changeLanguage("uz")
    }
    else{
      this.changeLanguage(lang)
    }

    const hasSeenIntro = await Storage.get({key: INTRO_KEY});      
      if (hasSeenIntro && (hasSeenIntro.value === 'true')) {
        this.showLoginButton = true;
        
      } else {
        this.showLoginButton = false;
        
      }

      this.networkListener = Network.addListener('networkStatusChange', (status) => {
        console.log("Network status changed", status);
        this.networkStatus = status;
      });
  
      this.networkStatus = await Network.getStatus();
  
      if (this.networkStatus && this.networkStatus.connected) {
        this.apiService.getAllItem("/click").subscribe(res =>{
          if(res["success"] == true){
            window.localStorage.setItem("using_count", String(res["count"]));
            this.using_count = res["count"]
          }
        })
      }
      else{
        this.using_count = window.localStorage.getItem("using_count");
        
      }

  }


  count(){
    return this.using_count
  }

  hide(){
    this.showLoginButton = true;
    this.isAuthenticated.next(false);
  }
  
  log(){
    Storage.set({key: INTRO_KEY, value: "true"})
    this.isAuthenticated.next(true);
  }

  logout(){
    this.authService.logout();
    this.showLoginButton = false;
    this.router.navigateByUrl('/login-and-register');
  }

  public changeLanguage(language): void {
    this._translate.use(language);
    window.localStorage.setItem("LanguageInterface", language);
    try {
      window.home.changeLanguage(language)
      window.login.changeLanguage(language)
      window.phone.changeLanguage(language)
      window.portfolio.changeLanguage(language)
      window.givework.changeLanguage(language)
      window.findwork.changeLanguage(language)
    } catch (error) {
      
    }
  }

  showSide(){
    setTimeout(() => {
      this.endSide = true;
    }, 100);
  }
}
