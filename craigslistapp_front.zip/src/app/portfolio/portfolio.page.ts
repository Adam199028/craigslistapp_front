import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../services/api.service';
import { Router } from '@angular/router';

import { Plugins, NetworkStatus, PluginListenerHandle } from '@capacitor/core';
import { AlertController, LoadingController } from '@ionic/angular';
const { Storage } = Plugins;
import { PhoneValidator } from './../validators/phone';
import { JargonValidator } from './../validators/jargon';
import { TranslateService } from '@ngx-translate/core';


const { Network } = Plugins;
declare var window
@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.page.html',
  styleUrls: ['./portfolio.page.scss'],
})
export class PortfolioPage implements OnInit {

  REGIONS = ['Toshkent shahri', 'Toshkent viloyati', "Farg'ona viloyati", 'Andijon viloyati', 
  'Namangan viloyati', "Jizzax viloyati", 'Sirdaryo viloyati', 'Qashqadaryo viloyati', 
  "Surxondaryo viloyati", 'Samarqand viloyati', 'Buxoro viloyati', 'Navoiy viloyati', 
  'Xorazm viloyati', "Qoraqalpog'iston Respublikasi"]
  
  DISTRICTS = [
    // Toshkent shahar
    [" Bektemir tumani", "Chilonzor tumani", "Hamza tumani",
    "Mirobod tumani", "Mirzo Ulug'bek tumani", 
    "Sergeli tumani", "Shayxontohur tumani", "Olmazor tumani", 
    "Uchtepa", "Yakkasaroy tumani", "Yunusobod tumani"],
    // Toshkent viloyati
    ["Bekobod tumani", "Bo'stonliq tumani", "Bo'ka tumani",
    "Chinoz tumani", "Qibray tumani",
    "Ohangaron tumani", "Oqqo'rg'on tumani", "Parkent tumani", 
    "Piskent tumani", "Quyi chirchiq tumani", "O'rta Chirchiq tumani",
    "Yangiyo'l tumani", "Yuqori Chirchiq tumani", "Zangiota tumani"],
    // Farg'ona
    ["Oltiariq tumani", "Bag'dod tumani", "Beshariq tumani",
    "Buvayda tumani", "Dang'ara tumani", "Farg'ona tumani",
    "Furqat tumani", "Qo'shtepa tumani","Quva tumani",
    "Rishton tumani", "So'x tumani", "Toshloq tumani",
    "Uchko'prik tumani", "O'zbekiston tumani", "Yozyovon tumani"],
    // Andijon
    ["Andijon tumani", "Asaka tumani", "Baliqchi tumani",
    "Bo'z tumani", "Buloqboshi tumani", "Izboskan tumani",
    "Jalaquduq tumani", "Xo'jaobod tumani", "Qo'rg'ontepa tumani",
    "Marhamat tumani", "Oltinko'l tumani", "Paxtaobod tumani",
    "Shahrixon tumani", "Ulug'nor tumani"],
    // Namangan
    ["Chortoq tumani",
    "Chust tumani",
    "Kosonsoy tumani",
    "Mingbuloq tumani",
    "Namangan tumani",
    "Norin tumani",
    "Pop tumani",
    "To'raqo'rg'on tumani",
    "Uchqo'rg'on tumani",
    "Uychi tumani",
    "Yangiqo'rg'on tumani"],
    // Jizzax 
    ["Arnasoy tumani",
    "Baxmal tumani",
    "Do'stlik tumani",
    "Forish tumani",
    "G'allaorol tumani",
    "Sharof Rashidov tumani",
    "Mirzacho'l tumani",
    "Paxtakor tumani",
    "Yangiobod tumani",
    "Zomin tumani",
    "Zafarobod tumani",
    "Zarbdor tumani"],
    // Sirdaryo
    ["Oqoltin tumani",
    "Boyovut tumani",
    "Guliston tumani",
    "Xovos tumani",
    "Mirzaobod tumani",
    "Sayxunobod tumani",
    "Sardoba tumani",
    "Sirdaryo tumani"],
    // Qashqadaryo
    ["Chiroqchi tumani",
    "Dehqonobod tumani",
    "G'uzor tumani",
    "Qamashi tumani",
    "Qarshi tumani",
    "Koson tumani",
    "Kasbi tumani",
    "Kitob tumani",
    "Mirishkor tumani",
    "Muborak tumani",
    "Nishon tumani",
    "Shahrisabz tumani",
    "Yakkabog' tumani"],
    // Surxondaryo
    ["Angor tumani",
    "Boysun tumani",
    "Denov tumani",
    "Jarqo'rg'on tumani",
    "Qiziriq tumani",
    "Qumqo'rg'on tumani",
    "Muzrabot tumani",
    "Oltinsoy tumani",
    "Sariosiyo tumani",
    "Sherobod tumani",
    "Sho'rchi tumani",
    "Termiz tumani",
    "Uzun tumani"],
    // Samarqand
    ["Bulung'ur tumani",
    "Ishtixon tumani",
    "Jomboy tumani",
    "Kattaqo'rg'on tumani",
    "Qo'shrabot tumani",
    "Narpay tumani",
    "Nurobod tumani",
    "Oqdaryo tumani",
    "Paxtachi tumani",
    "Payariq tumani",
    "Pastdarg'om tumani",
    "Samarqand tumani",
    "Toyloq tumani",
    "Urgut tumani"],
    // Buxoro
    ["Olot tumani",
    "Buxoro tumani",
    "G'ijduvon tumani",
    "Jondor tumani",
    "Kogon tumani",
    "Qorako'l tumani",
    "Qorovulbozor tumani",
    "Peshku tumani",
    "Romitan tumani",
    "Shofirkon tumani",
    "Vobkent tumani"],
    // Navoiy
    ["Konimex tumani",
    "Karmana tumani",
    "Qiziltepa tumani",
    "Xatirchi tumani",
    "Navbahor tumani",
    "Nurota tumani",
    "Tomdi tumani",
    "Uchquduq tumani"],
    // Xorazm
    ["Bog'ot tumani",
    "Gurlan tumani",
    "Xonqa tumani",
    "Hazorasp tumani",
    "Xiva tumani",
    "Qo'shko'pir tumani",
    "Shovot tumani",
    "Urganch tumani",
    "Yangiariq tumani",
    "Yangibozor tumani",
    "Tuproqqal'a tumani"],
    // Qoraqalpog'iston 
    ["Amudaryo tumani",
    "Beruniy tumani",
    "Chimboy tumani",
    "Ellikqal'a tumani",
    "Kegeyli tumani",
    "Mo'ynoq tumani",
    "Nukus tumani",
    "Qanliko'l tumani",
    "Qo'ng'irot tumani",
    "Qorao'zak tumani",
    "Shumanay tumani",
    "Taxtako'pir tumani",
    "To'rtko'l tumani",
    "Xo'jayli tumani"]
  ]

  SelectDistrict = []
  constructor(
    private _translate: TranslateService,
    private apiService: ApiService,
    private router: Router,
    private loadingController: LoadingController,
    private alertController: AlertController
  ) {
    window.portfolio = this
   }




  networkStatus: NetworkStatus;
  networkListener: PluginListenerHandle;

  showPortfolioInfo: boolean = false

  portfolioForm = new FormGroup({
    id: new FormControl(""),
    stars: new FormControl("0"),
    fullname: new FormControl("", Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    username: new FormControl({ value: "", disabled: true }, Validators.required),
    email: new FormControl({ value: "", disabled: true }, Validators.required),
    phone_number: new FormControl("", Validators.compose([
      PhoneValidator.isValid,
      Validators.required
    ])),
    region: new FormControl("", Validators.required),
    district: new FormControl("", Validators.required),
    org_name: new FormControl("", Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    portfolio: new FormControl("", Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    activity: new FormControl("",Validators.compose([
      JargonValidator.isValid,
      Validators.required
    ])),
    time: new FormControl("")
  });



  username = "";
  stars = "";
  id;
  indexRegion;


  async ngOnInit() {
    let lang = window.localStorage.getItem("LanguageInterface");
    if(lang == null){
      this.changeLanguage("uz")
    }
    else{
      this.changeLanguage(lang)
    }
    this.networkListener = Network.addListener('networkStatusChange', (status) => {
      console.log("Network status changed", status);
      this.networkStatus = status;
    });

    this.networkStatus = await Network.getStatus();

    let id = window.localStorage.getItem("UserID")
    let info = window.localStorage.getItem("UserInfo")
    info = null
    if (info == null) {
      if (this.networkStatus && this.networkStatus.connected) {
        this.apiService.newItem({ "id": id }, "/get_user").subscribe((data: any) => {
          console.log(data)
          if (data.length != 0) {
            window.localStorage.setItem("UserInfo", JSON.stringify(data))

            this.portfolioForm = new FormGroup({
              id: new FormControl(data[0]['id']),
              stars: new FormControl(data[0]['stars']),
              fullname: new FormControl(data[0]['fullname'], Validators.compose([
                JargonValidator.isValid,
                Validators.required
              ])),
              username: new FormControl({ value: data[0]['username'], disabled: true }, Validators.required),
              email: new FormControl({ value: data[0]['email'], disabled: true }, Validators.required),
              phone_number: new FormControl(data[0]['phone_number'], Validators.compose([
                PhoneValidator.isValid,
                Validators.required
              ])),
              region: new FormControl(data[0]['region'], Validators.required),
              district: new FormControl(data[0]['district'], Validators.required),
              org_name: new FormControl(data[0]['org_name'], Validators.compose([
                JargonValidator.isValid,
                Validators.required
              ])),
              portfolio: new FormControl(data[0]['portfolio'], Validators.compose([
                JargonValidator.isValid,
                Validators.required
              ])),
              activity: new FormControl(data[0]['activity'], Validators.compose([
                JargonValidator.isValid,
                Validators.required
              ])),
              time: new FormControl(data[0]['time'])
            });
            let i = this.REGIONS.findIndex(item => item == data[0]["region"])
            this.SelectDistrict = this.DISTRICTS[i];
            this.username = data[0]['username']
            this.stars = data[0]['stars']
            this.id = data[0]['id']
          }
          else {
            this.router.navigateByUrl('/login-and-register', { replaceUrl: true });
          }
        })
      }
      else {
        const alert = await this.alertController.create({
          header: "Internetga ulanmagansiz.",
          message: "",
          buttons: ['OK'],
        });

        await alert.present();
      }

    }
    else {
      let data = JSON.parse(info)
      this.portfolioForm = new FormGroup({
        id: new FormControl(data[0]['id']),
        stars: new FormControl(data[0]['stars']),
        fullname: new FormControl(data[0]['fullname'], Validators.compose([
          JargonValidator.isValid,
          Validators.required
        ])),
        username: new FormControl({ value: data[0]['username'], disabled: true }, Validators.required),
        email: new FormControl({ value: data[0]['email'], disabled: true }, Validators.required),
        
        phone_number: new FormControl(data[0]['phone_number'], Validators.compose([
          PhoneValidator.isValid,
          Validators.required
        ])),
        region: new FormControl(data[0]['region'], Validators.required),
        district: new FormControl(data[0]['district'], Validators.required),
        org_name: new FormControl(data[0]['org_name'], Validators.compose([
          JargonValidator.isValid,
          Validators.required
        ])),
        portfolio: new FormControl(data[0]['portfolio'], Validators.compose([
          JargonValidator.isValid,
          Validators.required
        ])),
        activity: new FormControl(data[0]['activity'],Validators.compose([
          JargonValidator.isValid,
          Validators.required
        ])),
        time: new FormControl(data[0]['time'])
      });
      let i = this.REGIONS.findIndex(item => item == data[0]["region"])
      this.SelectDistrict = this.DISTRICTS[i];
      this.username = data[0]['username']
      this.stars = data[0]['stars']
      this.id = data[0]['id']
    }

  }

  ngOnDestroy() {
    this.networkListener.remove();
  }

  public changeLanguage(language): void {
    this._translate.use(language);
  }



  async portfolioSave(status) {
    let loading = await this.loadingController.create();
    if (status == "on") {

      await loading.present();
    }

    if (this.networkStatus && this.networkStatus.connected) {
      this.apiService.updateItem(this.id, this.portfolioForm.value, "/users").subscribe(async res => {
        console.log(res)
        await loading.dismiss();

        let title = "";
        if (res["success"] == true) {
          window.localStorage.setItem("UserInfo", JSON.stringify([this.portfolioForm.value]))
          title = "Ma'lumotlar saqlandi."
        } else {
          title = "Ma'lumotlar saqlanmadi."
        }
        if (status == "on") {
          const alert = await this.alertController.create({
            header: title,
            message: "",
            buttons: ['OK'],
          });

          await alert.present();
        }
      })
    }

    else {
      if (status == "on") {
        const alert = await this.alertController.create({
          header: "Internetga ulanmagansiz.",
          message: "",
          buttons: ['OK'],
        });

        await alert.present();
      }

    }


  }

  changeRegion(event) {

    console.log(event.target.value)
    let i = this.REGIONS.findIndex(item => item == event.target.value)
    this.SelectDistrict = this.DISTRICTS[i];
  }


  async addInfo() {
    if (this.networkStatus && this.networkStatus.connected) {
      const loading = await this.loadingController.create();
      await loading.present();
      let phoneForm = {
        user_id: this.portfolioForm.value["id"],
        org_name: this.portfolioForm.value["org_name"],
        address: this.portfolioForm.value["region"] + ", " + this.portfolioForm.value["district"] + " tumani",
        activity: this.portfolioForm.value["activity"],
        phone_number: this.portfolioForm.value["phone_number"]
      }
      this.apiService.newItem(phoneForm, "/newphone_numbers").subscribe(async result => {
        console.log(result)
        let title = "";
        await loading.dismiss();
        if (result["success"] == true) {
          title = "Ma'lumotlar kiritildi."
          this.portfolioSave("off")
        } else {
          if (result["status"] == "busy") {
            title = "Kechirasiz, bu telefon raqamni boshqa foydalanuvchi kiritgan. Admin: +998 90 309 39 78"
          }
          else {
            title = "Ma'lumotlar kiritishda xatolik yuzaga keldi."
          }

        }

        const alert = await this.alertController.create({
          header: title,
          message: "",
          buttons: ['OK'],
        });

        await alert.present();
      })

    }
    else {
      const alert = await this.alertController.create({
        header: "Internetga ulanmagansiz.",
        message: "",
        buttons: ['OK'],
      });

      await alert.present();
    }

  }

}
