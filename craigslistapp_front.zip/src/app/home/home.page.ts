import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Plugins, NetworkStatus, PluginListenerHandle } from '@capacitor/core';
const { Storage } = Plugins;
import { TranslateService } from '@ngx-translate/core';
import { ApiService } from '../services/api.service';


const { Network } = Plugins;


declare var window
@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit, OnDestroy {

  constructor(
    private _translate: TranslateService,
    private router: Router,
    private apiService: ApiService
  ) { 
    window.home = this;
  }

  networkStatus: NetworkStatus;
  networkListener: PluginListenerHandle;

  using_count = ""
  showCount: boolean = true

  async ngOnInit() {
    let lang = window.localStorage.getItem("LanguageInterface");
    if(lang == null){
      this.changeLanguage("uz")
    }
    else{
      this.changeLanguage(lang)
    }

    this.networkListener = Network.addListener('networkStatusChange', (status) => {
      console.log("Network status changed", status);
      this.networkStatus = status;
    });

    this.networkStatus = await Network.getStatus();

    
    let timer = setInterval(() =>{
      this.using_count = window.app.count()
      if(this.using_count != ""){
        window.clearInterval(timer)
      }
    }, 100)
    // if (this.networkStatus && this.networkStatus.connected) {
    //   this.apiService.getAllItem("/click").subscribe(res =>{
    //     if(res["success"] == true){
    //       this.showCount = true
    //       this.using_count = res["count"]
    //     }
    //   })
    // }
    // else{
      
    //   this.showCount = true
    // }

  }

  ngOnDestroy() {
    this.networkListener.remove();
  }

  public changeLanguage(language): void {
    this._translate.use(language);
  }
  
}
