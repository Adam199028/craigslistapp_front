import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Plugins, NetworkStatus, PluginListenerHandle } from '@capacitor/core';
const { Network } = Plugins;

@Component({
  selector: 'app-help',
  templateUrl: './help.page.html',
  styleUrls: ['./help.page.scss'],
})
export class HelpPage implements OnInit {

  constructor(
    private _translate: TranslateService
  ) { }

  networkStatus: NetworkStatus;
  networkListener: PluginListenerHandle;

  async ngOnInit() {
    let lang = window.localStorage.getItem("LanguageInterface");
    if(lang == null){
      this.changeLanguage("uz")
    }
    else{
      this.changeLanguage(lang)
    }
    this.networkListener = Network.addListener('networkStatusChange', (status) => {
      console.log("Network status changed", status);
      this.networkStatus = status;
    });

    this.networkStatus = await Network.getStatus();

  }

  ngOnDestroy() {
    this.networkListener.remove();
  }

  public changeLanguage(language): void {
    this._translate.use(language);
  }

}
