import { FormControl } from '@angular/forms';

export class JargonValidator {

    static isValid(control: FormControl): any {

        let txt = control.value
        txt = txt.toLowerCase();

        if((txt.indexOf("sexy") !== -1) || (txt.indexOf("qo'taq") !== -1) || (txt.indexOf(" ko't ") !== -1) || 
        (txt.indexOf("dabba") !== -1) || (txt.indexOf("xaromxo'r") !== -1) || (txt.indexOf("dalbayob") !== -1) ||
        (txt.indexOf(" terrorist ") !== -1) || (txt.indexOf("seks") !== -1) || (txt.indexOf(" amingga ") !== -1)){
            return {isValid: true} 
        }
        else{
            return null
            
        }
        return null

    }

}